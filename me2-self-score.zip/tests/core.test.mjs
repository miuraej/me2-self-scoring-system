import test from 'node:test';
import assert from 'node:assert/strict';
import {scoreAnswer,scoreSubmission,parseCsv,validateSubmission,toCsv,validateData} from '../js/core.js';
const exam={examId:'E1',formatVersion:'1'};
const questions=[
 {id:'q1',examId:'E1',section:'trial',number:1,category:'A',choiceCount:5,choices:['1','2','3','4','5'],correctAnswers:[2],scoring:'normal'},
 {id:'q2',examId:'E1',section:'trial',number:2,category:'B',choiceCount:5,choices:['1','2','3','4','5'],correctAnswers:[1,4],scoring:'multiple'},
 {id:'q3',examId:'E1',section:'trial',number:3,category:'C',choiceCount:5,choices:['1','2','3','4','5'],correctAnswers:[],scoring:'all_correct'},
 {id:'q4',examId:'E1',section:'trial',number:4,category:'D',choiceCount:5,choices:['1','2','3','4','5'],correctAnswers:[],scoring:'excluded'}];
test('all scoring modes',()=>{assert.equal(scoreAnswer('2',questions[0]).earned,1);assert.equal(scoreAnswer('4',questions[1]).earned,1);assert.equal(scoreAnswer('',questions[2]).earned,1);assert.equal(scoreAnswer('1',questions[3]).possible,0)});
test('missing and unanswered remain distinct',()=>{assert.equal(scoreAnswer('',questions[0]).status,'missing');assert.equal(scoreAnswer('U',questions[0]).status,'unanswered')});
test('submission totals exclude excluded question',()=>{const s=scoreSubmission({q1:'2',q2:'3',q3:'U',q4:'1'},questions);assert.deepEqual([s.earned,s.possible],[2,3])});
test('CSV round trip preserves blanks, U and quoted names',()=>{const csv=toCsv([{exam_id:'E1',format_version:'1',student_name:'姓, 名',TRIAL01:'',TRIAL02:'U'}]);const [row]=parseCsv(csv);assert.equal(row.student_name,'姓, 名');assert.equal(row.TRIAL01,'');assert.equal(row.TRIAL02,'U')});
test('submission validation catches ids and values',()=>{const v=validateSubmission({exam_id:'bad',format_version:'2',TRIAL01:'9'},exam,questions);assert.equal(v.warnings.length,3)});
test('public data validation accepts fixture',()=>assert.deepEqual(validateData(exam,questions),[]));
